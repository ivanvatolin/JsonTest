package ru.van;

public class XMLParser {

    public Order parse(String line) {
        Order order = new Order();
        String arrLine[] = line.split(" ");
        String item = "";
        for (int i = 0; i < arrLine.length; i++) {
            item = arrLine[i];
            int count=0;
            StringBuilder s=new StringBuilder();
            for (int j = 0; j < item.length(); j++) {
                if(item.contains("book"));
            }

        }
        return order;
    }
}
