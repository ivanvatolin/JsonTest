package ru.van;

import java.io.BufferedReader;
import java.io.FileReader;

public class Main {
    public static void main(String args[]) throws Exception{
        long start=System.currentTimeMillis();
            new Main().run();
        long end=System.currentTimeMillis();
        System.out.println(end-start+" ms");

    }

    public void run() throws Exception{
        XMLParser parser = new XMLParser();
        int count=0;
        String line;
        BufferedReader reader = new BufferedReader(new FileReader("orders.xml"));
            while ((line=reader.readLine())!=null){
                if(line.startsWith("<AddOrder")){
                    Order order = new Order();
//                    order = parser.parse(line);
                }
            }

            System.out.println(count);
        reader.close();
    }

}
