package ru.van;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Van on 21.02.17.
 */
public class BookOrder {

    private Map<Integer, Order> sellOrders = new HashMap<>();
    private Map<Integer, Order> buyOrders = new HashMap<>();

    public void addOrder(Order order) {
        switch (order.getOperation()) {
            case "SELL":
                sellOrders.put(order.getOrderId(), order);
            case "BUY":
                buyOrders.put(order.getOrderId(), order);
        }
    }

    public void removeOrder(int orderId) {
        if(sellOrders.containsKey(orderId)) {
            sellOrders.remove(orderId);
        }else if(buyOrders.containsKey(orderId)) {
            buyOrders.remove(orderId);
        }
    }
}
