from django.shortcuts import render
from .forms import *
from datetime import date
import json

def landing(request):
    cur_date=date.today()
    form = SubscriberForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        # print(form)
        # print(form.cleaned_data)
        form.save()
        # new_form=form.clean()
        # form2 = FormsForm(None)
        # form2.save()
    return render(request, 'landing/landing.html', locals())

def home(request):
    return render(request, 'landing/home.html', locals())